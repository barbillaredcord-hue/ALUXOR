# ALUXOR / BR
# Roadmap Documentation Index

## Estado actual

- Era I completada.
- Fase 22 completada.
- Fase 23 completada.
- Fase 23.5 en ejecución.
- Fase 23.5 Día 1 cerrado y aprobado.
- Fase 23.5 Día 2 iniciado.
- Fase 24 aún no ha iniciado.

## Siguiente paso inmediato

Cerrar Fase 23.5 Día 2: Workspace 2.0 guiado por estaciones.

## Contexto operativo

- ALUXOR se organiza alrededor del proyecto, no de módulos aislados.
- Project First Architecture sigue como principio rector.
- La base visual del Workspace fue compactada durante Día 2.
- El estado "Sin conexión / Usando copia local" fue ajustado.
- `history.js` quedó preparado para backend remoto con `VITE_HISTORY_API_URL`.
- El backend remoto de historial aún no está implementado.
- Build estable.

## Documentos principales

- `docs/roadmap/roadmap-maestro-aluxor-br.md`
- `docs/roadmap/libro-maestro-aluxor-br.md`
- `docs/roadmap/eras/era-2-erp-operativo.md`
- `docs/roadmap/workflow-engine.md`
- `docs/design-system-br.md`
- `docs/ui-blueprint-aluxor.md`
- `docs/reviews/phase-23.5-day-1-review.md`
- `docs/reviews/document-consistency-report-phase-23.5.md`

## Nota sobre Fase 24

Fase 24 permanece pendiente. Solo debe iniciar después de cerrar Fase 23.5.
