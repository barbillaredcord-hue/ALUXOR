# Continuidad para ChatGPT / Codex

ALUXOR / BR es un ERP operativo centrado en proyectos, no en módulos aislados.

## Estado real

- Era I completada.
- Fase 22 completada.
- Fase 23 completada.
- Fase 23.5 en ejecución.
- Día 1 de Fase 23.5 cerrado y aprobado.
- Día 2 de Fase 23.5 iniciado.
- Fase 24 aún no ha iniciado.

## Principios vigentes

- Project First Architecture es el principio rector.
- El proyecto es la unidad central de navegación, trabajo e historial.
- La cotización es una etapa del proyecto, no el producto principal.
- Los módulos existen como capacidades internas al servicio del proyecto.
- BR Design System es la base visual aprobada.

## Trabajo reciente

- Workspace 2.0 Día 2 iniciado.
- Base visual del Workspace compactada.
- Estado "Sin conexión / Usando copia local" ajustado.
- Project First Architecture preservada.
- Build estable.

## Historial remoto

- `history.js` está preparado para consumir `VITE_HISTORY_API_URL`.
- El backend remoto de historial aún no está implementado.
- No confundir "preparado para backend remoto" con "backend remoto implementado".

## Siguiente paso inmediato

Cerrar Fase 23.5 Día 2: Workspace 2.0 guiado por estaciones.

Después de cerrar Fase 23.5, se podrá iniciar Fase 24: Trazabilidad Operativa / Workflow Engine / eventos / estados / historial remoto.
