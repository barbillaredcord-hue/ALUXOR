# ALUXOR / BR
# Contexto Vivo del Proyecto

Esta carpeta centraliza el contexto operativo vigente de ALUXOR para futuras sesiones de ChatGPT y Codex.

## Archivos

- `continuidad-chatgpt.md`: contexto breve para pegar en nuevas conversaciones.
- `project-state.md`: estado actual del proyecto, fases y pendientes.
- `session-log.md`: registro resumido de continuidad.
- `architecture-principles.md`: principios arquitectónicos y visuales vigentes.

## Estado actual

- Era I completada.
- Fase 22 completada.
- Fase 23 completada.
- Fase 23.5 en ejecución.
- Fase 23.5 Día 1 cerrado y aprobado.
- Fase 23.5 Día 2 iniciado.
- Fase 24 aún no ha iniciado.

## Siguiente paso inmediato

Cerrar Fase 23.5 Día 2: Workspace 2.0 guiado por estaciones.

## Fuentes oficiales

- `docs/roadmap/roadmap-maestro-aluxor-br.md`
- `docs/roadmap/libro-maestro-aluxor-br.md`
- `docs/roadmap/eras/era-2-erp-operativo.md`
- `docs/roadmap/workflow-engine.md`
- `docs/design-system-br.md`
- `docs/ui-blueprint-aluxor.md`
- `docs/reviews/phase-23.5-day-1-review.md`
- `docs/reviews/document-consistency-report-phase-23.5.md`
